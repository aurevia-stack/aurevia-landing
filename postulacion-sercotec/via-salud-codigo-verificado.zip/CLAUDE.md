# VÍA Salud — contexto del proyecto (Prompt 0)
Plataforma SaaS chilena que reduce listas de espera recuperando horas médicas perdidas por inasistencia.
Ciclo: importar agenda (calendario espejo CSV) → confirmar por WhatsApp con asistente IA → detectar citas en riesgo →
rescatar la hora liberada ofreciéndola a la lista de rescate → panel y bitácora auditable.
Reglas: datos mínimos (nombre, teléfono, cita; SIN ficha clínica) · bitácora append-only con cadena de hashes ·
ninguna decisión clínica automática · el asistente jamás da consejo médico · multi-centro desde el día 1.
Stack: Python + SQLAlchemy + PostgreSQL · asistente con SDK oficial de Anthropic · tests con pytest.
