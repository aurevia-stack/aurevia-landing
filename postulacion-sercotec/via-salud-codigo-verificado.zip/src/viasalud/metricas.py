"""Métricas del panel y del reporte (Prompts 6-7). Una sola fuente de cálculo."""
from sqlalchemy import func, select

from .models import Centro, Cita, OfertaRescate


def resumen(session, centro: Centro) -> dict:
    def contar(estado):
        return session.execute(select(func.count()).where(
            Cita.centro_id == centro.id, Cita.estado == estado)).scalar_one()

    rescatadas = session.execute(select(Cita).where(
        Cita.centro_id == centro.id, Cita.estado == "rescatada")).scalars().all()
    minutos = sum(c.duracion_min for c in rescatadas)
    ofertas = session.execute(select(func.count()).where(
        OfertaRescate.centro_id == centro.id)).scalar_one()
    aceptadas = session.execute(select(func.count()).where(
        OfertaRescate.centro_id == centro.id,
        OfertaRescate.estado == "aceptada")).scalar_one()
    total = session.execute(select(func.count()).where(
        Cita.centro_id == centro.id)).scalar_one()
    return {
        "citas_total": total,
        "confirmadas": contar("confirmada"),
        "liberadas_sin_rescatar": contar("liberada"),
        "rescatadas": len(rescatadas),
        "horas_rescatadas": round(minutos / 60, 1),
        "pesos_recuperados": int(minutos / 60 * centro.tarifa_hora),
        "ofertas_enviadas": ofertas,
        "tasa_aceptacion_ofertas": round(aceptadas / ofertas, 2) if ofertas else 0.0,
    }
