"""Bitácora append-only con cadena de hashes (Prompt 1/3)."""
import hashlib
import json
from datetime import datetime

from sqlalchemy import select

from .models import EventoBitacora

GENESIS = "0" * 64


def _hash(prev: str, centro_id: int, ts: str, tipo: str, entidad: str,
          entidad_id, payload: str) -> str:
    base = "|".join([prev, str(centro_id), ts, tipo, entidad, str(entidad_id), payload])
    return hashlib.sha256(base.encode()).hexdigest()


def registrar(session, centro_id: int, tipo: str, entidad: str,
              entidad_id=None, payload: dict | None = None) -> EventoBitacora:
    ultimo = session.execute(
        select(EventoBitacora).where(EventoBitacora.centro_id == centro_id)
        .order_by(EventoBitacora.id.desc()).limit(1)
    ).scalar_one_or_none()
    prev = ultimo.hash if ultimo else GENESIS
    ts = datetime.utcnow()
    payload_json = json.dumps(payload or {}, sort_keys=True, ensure_ascii=False)
    ev = EventoBitacora(
        centro_id=centro_id, ts=ts, tipo=tipo, entidad=entidad,
        entidad_id=entidad_id, payload=payload_json, hash_anterior=prev,
        hash=_hash(prev, centro_id, ts.isoformat(), tipo, entidad, entidad_id, payload_json),
    )
    session.add(ev)
    session.flush()
    return ev


def verificar_cadena(session, centro_id: int) -> bool:
    """Recorre la cadena completa y valida cada hash."""
    eventos = session.execute(
        select(EventoBitacora).where(EventoBitacora.centro_id == centro_id)
        .order_by(EventoBitacora.id)
    ).scalars().all()
    prev = GENESIS
    for ev in eventos:
        esperado = _hash(prev, ev.centro_id, ev.ts.isoformat(), ev.tipo,
                         ev.entidad, ev.entidad_id, ev.payload)
        if ev.hash_anterior != prev or ev.hash != esperado:
            return False
        prev = ev.hash
    return True
