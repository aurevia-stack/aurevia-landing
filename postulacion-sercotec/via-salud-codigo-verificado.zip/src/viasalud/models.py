from datetime import datetime
from sqlalchemy import (Boolean, Column, DateTime, Float, ForeignKey, Integer,
                        String, Text, UniqueConstraint, text)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class Centro(Base):
    __tablename__ = "centro"
    id = Column(Integer, primary_key=True)
    nombre = Column(String(120), nullable=False)
    comuna = Column(String(80), nullable=False)
    tarifa_hora = Column(Integer, nullable=False, default=30000)  # CLP, para valorizar horas
    oferta_expira_min = Column(Integer, nullable=False, default=20)
    config_mapeo = Column(Text)  # JSON: mapeo de columnas del import


class Profesional(Base):
    __tablename__ = "profesional"
    id = Column(Integer, primary_key=True)
    centro_id = Column(ForeignKey("centro.id"), nullable=False, index=True)
    nombre = Column(String(120), nullable=False)
    especialidad = Column(String(80), nullable=False)
    __table_args__ = (UniqueConstraint("centro_id", "nombre"),)


class PacienteContacto(Base):
    __tablename__ = "paciente_contacto"
    id = Column(Integer, primary_key=True)
    centro_id = Column(ForeignKey("centro.id"), nullable=False, index=True)
    nombre = Column(String(120), nullable=False)
    telefono = Column(String(20))  # E.164; None => incontactable
    incontactable = Column(Boolean, nullable=False, default=False)
    consentimiento_registrado = Column(Boolean, nullable=False, default=False)
    opt_out = Column(Boolean, nullable=False, default=False)
    __table_args__ = (UniqueConstraint("centro_id", "nombre", "telefono"),)


ESTADOS_CITA = ("agendada", "confirmada", "en_riesgo", "liberada", "rescatada",
                "atendida", "perdida")


class Cita(Base):
    __tablename__ = "cita"
    id = Column(Integer, primary_key=True)
    centro_id = Column(ForeignKey("centro.id"), nullable=False, index=True)
    profesional_id = Column(ForeignKey("profesional.id"), nullable=False)
    paciente_id = Column(ForeignKey("paciente_contacto.id"), nullable=False)
    fecha_hora = Column(DateTime, nullable=False, index=True)
    duracion_min = Column(Integer, nullable=False, default=30)
    estado = Column(String(20), nullable=False, default="agendada")
    origen_rescate_id = Column(ForeignKey("cita.id"))  # cita liberada que esta rescata
    profesional = relationship("Profesional")
    paciente = relationship("PacienteContacto", foreign_keys=[paciente_id])
    __table_args__ = (UniqueConstraint("centro_id", "profesional_id", "fecha_hora", "paciente_id"),)


class ListaRescate(Base):
    __tablename__ = "lista_rescate"
    id = Column(Integer, primary_key=True)
    centro_id = Column(ForeignKey("centro.id"), nullable=False, index=True)
    paciente_id = Column(ForeignKey("paciente_contacto.id"), nullable=False)
    especialidad = Column(String(80), nullable=False)
    prioridad = Column(Integer, nullable=False, default=100)  # menor = primero
    origen = Column(String(20), nullable=False, default="manual")  # adelanto|sin_cupo|manual
    activo = Column(Boolean, nullable=False, default=True)
    creado_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    paciente = relationship("PacienteContacto")


class OfertaRescate(Base):
    __tablename__ = "oferta_rescate"
    id = Column(Integer, primary_key=True)
    centro_id = Column(ForeignKey("centro.id"), nullable=False, index=True)
    cita_liberada_id = Column(ForeignKey("cita.id"), nullable=False)
    paciente_id = Column(ForeignKey("paciente_contacto.id"), nullable=False)
    enviada_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    expira_at = Column(DateTime, nullable=False)
    estado = Column(String(12), nullable=False, default="enviada")  # enviada|aceptada|rechazada|expirada
    paciente = relationship("PacienteContacto")


class Conversacion(Base):
    __tablename__ = "conversacion"
    id = Column(Integer, primary_key=True)
    centro_id = Column(ForeignKey("centro.id"), nullable=False, index=True)
    paciente_id = Column(ForeignKey("paciente_contacto.id"), nullable=False)
    needs_human = Column(Boolean, nullable=False, default=False)
    paciente = relationship("PacienteContacto")


class Mensaje(Base):
    __tablename__ = "mensaje"
    id = Column(Integer, primary_key=True)
    conversacion_id = Column(ForeignKey("conversacion.id"), nullable=False, index=True)
    direccion = Column(String(3), nullable=False)  # in|out
    cuerpo = Column(Text, nullable=False)
    creado_at = Column(DateTime, nullable=False, default=datetime.utcnow)


class EventoBitacora(Base):
    __tablename__ = "evento_bitacora"
    id = Column(Integer, primary_key=True)
    centro_id = Column(Integer, nullable=False, index=True)
    ts = Column(DateTime, nullable=False, default=datetime.utcnow)
    tipo = Column(String(60), nullable=False)
    entidad = Column(String(40), nullable=False)
    entidad_id = Column(Integer)
    payload = Column(Text, nullable=False, default="{}")
    hash_anterior = Column(String(64), nullable=False)
    hash = Column(String(64), nullable=False)


TRIGGER_APPEND_ONLY = """
CREATE OR REPLACE FUNCTION bitacora_inmutable() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'evento_bitacora es append-only: % no permitido', TG_OP;
END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_bitacora_inmutable ON evento_bitacora;
CREATE TRIGGER trg_bitacora_inmutable
  BEFORE UPDATE OR DELETE ON evento_bitacora
  FOR EACH ROW EXECUTE FUNCTION bitacora_inmutable();
"""


def crear_esquema(engine):
    Base.metadata.create_all(engine)
    if engine.dialect.name == "postgresql":
        with engine.begin() as conn:
            conn.execute(text(TRIGGER_APPEND_ONLY))
