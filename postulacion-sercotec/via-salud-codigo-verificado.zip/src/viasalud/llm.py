"""Adaptador LLM del asistente (Prompt 4). Producción: SDK oficial de Anthropic
con tool use estricto. Tests: MockLLM determinista con las mismas herramientas."""
import json
import os

HERRAMIENTAS = [
    {"name": "confirmar_cita", "description": "El paciente confirma que asistirá a su cita.",
     "input_schema": {"type": "object", "properties": {}, "required": [],
                      "additionalProperties": False}, "strict": True},
    {"name": "marcar_no_asiste", "description": "El paciente indica que NO podrá asistir.",
     "input_schema": {"type": "object", "properties": {"motivo_general": {"type": "string"}},
                      "required": ["motivo_general"], "additionalProperties": False}, "strict": True},
    {"name": "escalar_a_humano", "description": ("Cualquier consulta clínica, urgencia, molestia del "
      "paciente o solicitud fuera de la gestión de citas."),
     "input_schema": {"type": "object", "properties": {"razon": {"type": "string"}},
                      "required": ["razon"], "additionalProperties": False}, "strict": True},
]

SYSTEM = ("Eres el asistente de agendamiento de {centro}. Tono cercano, chileno, breve, "
          "trato de usted. SOLO gestionas citas e información práctica. JAMÁS des consejo "
          "médico, diagnóstico ni interpretación de síntomas: ante cualquier consulta "
          "clínica o urgencia usa escalar_a_humano. No pidas ni registres datos de salud. "
          "Si el paciente se molesta o pide hablar con una persona, escala de inmediato.")


class MockLLM:
    """Simula la selección de herramienta por palabras clave, con el MISMO contrato
    (nombre de herramienta + input validado) que la implementación real."""
    def decidir(self, centro_nombre: str, texto: str) -> tuple[str, dict]:
        t = texto.lower()
        if any(k in t for k in ("confirmo", "ahí estaré", "asistiré", "voy a ir")):
            return "confirmar_cita", {}
        if any(k in t for k in ("no puedo", "no podré", "cancelar", "no voy")):
            return "marcar_no_asiste", {"motivo_general": "no puede asistir"}
        return "escalar_a_humano", {"razon": "consulta fuera de la gestión de citas"}


class AnthropicLLM:
    """Implementación real (requiere ANTHROPIC_API_KEY). Mismo contrato que MockLLM."""
    def __init__(self, model: str | None = None):
        import anthropic
        self.client = anthropic.Anthropic()
        self.model = model or os.environ.get("VIASALUD_MODEL", "claude-opus-5")

    def decidir(self, centro_nombre: str, texto: str) -> tuple[str, dict]:
        resp = self.client.messages.create(
            model=self.model, max_tokens=1024,
            system=SYSTEM.format(centro=centro_nombre),
            tools=HERRAMIENTAS,
            tool_choice={"type": "any"},
            messages=[{"role": "user", "content": texto}],
        )
        if resp.stop_reason == "refusal":
            return "escalar_a_humano", {"razon": "respuesta_rehusada"}
        for bloque in resp.content:
            if bloque.type == "tool_use":
                entrada = bloque.input if isinstance(bloque.input, dict) else json.loads(bloque.input)
                return bloque.name, entrada
        return "escalar_a_humano", {"razon": "sin_herramienta"}
