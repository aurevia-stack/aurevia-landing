"""Calendario espejo: importador CSV idempotente (Prompt 2)."""
import csv
import io
from datetime import datetime

from sqlalchemy import select

from . import bitacora
from .models import Centro, Cita, PacienteContacto, Profesional
from .telefonos import normalizar

ALIAS = {
    "fecha": {"fecha", "dia", "día", "date"},
    "hora": {"hora", "time", "hora cita"},
    "paciente": {"paciente", "nombre", "nombre paciente", "cliente"},
    "telefono": {"telefono", "teléfono", "fono", "celular", "phone", "movil", "móvil"},
    "profesional": {"profesional", "medico", "médico", "doctor", "dentista", "tratante"},
    "especialidad": {"especialidad", "area", "área", "servicio", "prestacion", "prestación"},
    "duracion": {"duracion", "duración", "minutos", "duracion_min"},
}


def _mapear_columnas(encabezados: list[str]) -> dict:
    mapa = {}
    for canon, alias in ALIAS.items():
        for i, h in enumerate(encabezados):
            if h.strip().lower() in alias:
                mapa[canon] = i
                break
    faltan = {"fecha", "hora", "paciente", "profesional"} - set(mapa)
    if faltan:
        raise ValueError(f"Columnas no reconocidas en el archivo: {sorted(faltan)}")
    return mapa


def _parse_fecha(fecha: str, hora: str) -> datetime:
    fecha = fecha.strip()
    for fmt in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            d = datetime.strptime(fecha, fmt)
            break
        except ValueError:
            continue
    else:
        raise ValueError(f"Fecha no reconocida: {fecha!r}")
    h, m = hora.strip().split(":")[:2]
    return d.replace(hour=int(h), minute=int(m))


def importar_csv(session, centro: Centro, contenido: str, canal=None) -> dict:
    """Importa la agenda del día. Idempotente. Marca liberadas las citas que
    desaparecen del archivo (canceladas en el software de origen)."""
    from .rescate import liberar_cita  # import tardío para evitar ciclo
    filas = list(csv.reader(io.StringIO(contenido)))
    mapa = _mapear_columnas(filas[0])
    stats = {"nuevas": 0, "actualizadas": 0, "liberadas": 0, "invalidas": 0, "incontactables": 0}
    vistas: set[int] = set()
    fechas_archivo: set[str] = set()

    for fila in filas[1:]:
        if not any(fila):
            continue
        try:
            fh = _parse_fecha(fila[mapa["fecha"]], fila[mapa["hora"]])
        except ValueError:
            stats["invalidas"] += 1
            continue
        fechas_archivo.add(fh.date().isoformat())
        nombre_pac = fila[mapa["paciente"]].strip()
        tel = normalizar(fila[mapa["telefono"]] if "telefono" in mapa else None)
        nombre_prof = fila[mapa["profesional"]].strip()
        espec = (fila[mapa["especialidad"]].strip() if "especialidad" in mapa else "General")
        dur = int(fila[mapa["duracion"]]) if "duracion" in mapa and fila[mapa["duracion"]].strip() else 30

        prof = session.execute(select(Profesional).where(
            Profesional.centro_id == centro.id, Profesional.nombre == nombre_prof
        )).scalar_one_or_none()
        if not prof:
            prof = Profesional(centro_id=centro.id, nombre=nombre_prof, especialidad=espec)
            session.add(prof)
            session.flush()

        pac = session.execute(select(PacienteContacto).where(
            PacienteContacto.centro_id == centro.id,
            PacienteContacto.nombre == nombre_pac,
            PacienteContacto.telefono == tel,
        )).scalar_one_or_none()
        if not pac:
            pac = PacienteContacto(centro_id=centro.id, nombre=nombre_pac,
                                   telefono=tel, incontactable=tel is None)
            session.add(pac)
            session.flush()
            if tel is None:
                stats["incontactables"] += 1

        cita = session.execute(select(Cita).where(
            Cita.centro_id == centro.id, Cita.profesional_id == prof.id,
            Cita.fecha_hora == fh, Cita.paciente_id == pac.id,
        )).scalar_one_or_none()
        if cita:
            if cita.duracion_min != dur:
                cita.duracion_min = dur
                stats["actualizadas"] += 1
        else:
            cita = Cita(centro_id=centro.id, profesional_id=prof.id,
                        paciente_id=pac.id, fecha_hora=fh, duracion_min=dur)
            session.add(cita)
            session.flush()
            stats["nuevas"] += 1
        vistas.add(cita.id)

    # citas del/los día(s) del archivo que ya no vienen => canceladas en origen
    if fechas_archivo:
        candidatas = session.execute(select(Cita).where(
            Cita.centro_id == centro.id,
            Cita.estado.in_(["agendada", "confirmada", "en_riesgo"]),
        )).scalars().all()
        for c in candidatas:
            if c.fecha_hora.date().isoformat() in fechas_archivo and c.id not in vistas:
                liberar_cita(session, c, motivo="desaparecida_en_import", canal=canal)
                stats["liberadas"] += 1

    bitacora.registrar(session, centro.id, "import_agenda", "centro", centro.id, stats)
    session.commit()
    return stats
