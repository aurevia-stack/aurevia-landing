"""Motor de rescate de cupos (Prompt 5): el corazón del producto."""
from datetime import datetime, timedelta

from sqlalchemy import select

from . import bitacora
from .canal import plantilla_oferta
from .models import Cita, ListaRescate, OfertaRescate


def liberar_cita(session, cita: Cita, motivo: str = "", canal=None):
    cita.estado = "liberada"
    bitacora.registrar(session, cita.centro_id, "cita_liberada", "cita", cita.id,
                       {"motivo": motivo})
    if canal is not None:
        ofrecer_siguiente(session, canal, cita)


def _candidatos(session, cita: Cita):
    espec = cita.profesional.especialidad
    ya_ofrecidos = [o.paciente_id for o in session.execute(select(OfertaRescate).where(
        OfertaRescate.cita_liberada_id == cita.id)).scalars()]
    q = select(ListaRescate).where(
        ListaRescate.centro_id == cita.centro_id,
        ListaRescate.activo.is_(True),
        ListaRescate.especialidad == espec,
    ).order_by(ListaRescate.prioridad, ListaRescate.creado_at)
    return [lr for lr in session.execute(q).scalars()
            if lr.paciente_id not in ya_ofrecidos
            and lr.paciente.telefono and not lr.paciente.opt_out]


def ofrecer_siguiente(session, canal, cita: Cita) -> OfertaRescate | None:
    """Ofrece la hora liberada al siguiente candidato de la cola. Secuencial."""
    if cita.estado != "liberada":
        return None
    cands = _candidatos(session, cita)
    if not cands:
        bitacora.registrar(session, cita.centro_id, "rescate_sin_candidatos", "cita", cita.id)
        return None
    lr = cands[0]
    from .models import Centro
    centro = session.get(Centro, cita.centro_id)
    oferta = OfertaRescate(
        centro_id=cita.centro_id, cita_liberada_id=cita.id, paciente_id=lr.paciente_id,
        expira_at=datetime.utcnow() + timedelta(minutes=centro.oferta_expira_min),
    )
    session.add(oferta)
    session.flush()
    canal.enviar(session, lr.paciente, plantilla_oferta(
        lr.paciente.nombre, centro.nombre, cita.fecha_hora.strftime("%d-%m-%Y"),
        cita.fecha_hora.strftime("%H:%M"), cita.profesional.nombre,
        centro.oferta_expira_min))
    bitacora.registrar(session, cita.centro_id, "oferta_enviada", "oferta", oferta.id,
                       {"paciente": lr.paciente_id, "cita": cita.id})
    return oferta


def procesar_respuesta_oferta(session, canal, centro, paciente, texto: str) -> str | None:
    """Si el paciente tiene una oferta vigente, la resuelve. None si no aplica."""
    oferta = session.execute(select(OfertaRescate).where(
        OfertaRescate.centro_id == centro.id,
        OfertaRescate.paciente_id == paciente.id,
        OfertaRescate.estado == "enviada",
    ).order_by(OfertaRescate.enviada_at.desc())).scalars().first()
    if not oferta:
        return None
    t = texto.strip().lower().rstrip(".!")
    cita_lib = session.get(Cita, oferta.cita_liberada_id)
    if datetime.utcnow() > oferta.expira_at:
        oferta.estado = "expirada"
        bitacora.registrar(session, centro.id, "oferta_expirada", "oferta", oferta.id)
        ofrecer_siguiente(session, canal, cita_lib)
        return None  # el mensaje del paciente sigue su flujo normal
    if t in {"si", "sí", "si quiero", "sí quiero", "la quiero", "acepto"}:
        oferta.estado = "aceptada"
        nueva = Cita(centro_id=centro.id, profesional_id=cita_lib.profesional_id,
                     paciente_id=paciente.id, fecha_hora=cita_lib.fecha_hora,
                     duracion_min=cita_lib.duracion_min, estado="rescatada",
                     origen_rescate_id=cita_lib.id)
        session.add(nueva)
        # el paciente sale de la lista de rescate
        for lr in session.execute(select(ListaRescate).where(
                ListaRescate.centro_id == centro.id,
                ListaRescate.paciente_id == paciente.id,
                ListaRescate.activo.is_(True))).scalars():
            lr.activo = False
        session.flush()
        bitacora.registrar(session, centro.id, "cupo_rescatado", "cita", nueva.id,
                           {"cita_liberada": cita_lib.id, "paciente": paciente.id})
        canal.enviar(session, paciente,
                     f"¡Listo! Su hora quedó tomada para el "
                     f"{cita_lib.fecha_hora.strftime('%d-%m-%Y a las %H:%M')}.")
        notificar_personal(session, canal, centro, nueva)
        return "oferta_aceptada"
    if t in {"no", "no gracias", "no puedo"}:
        oferta.estado = "rechazada"
        bitacora.registrar(session, centro.id, "oferta_rechazada", "oferta", oferta.id)
        canal.enviar(session, paciente, "Sin problema, seguirá en nuestra lista de avisos.")
        ofrecer_siguiente(session, canal, cita_lib)
        return "oferta_rechazada"
    return None


def expirar_ofertas(session, canal, ahora: datetime | None = None) -> int:
    """Tarea programada: expira ofertas vencidas y pasa al siguiente candidato."""
    ahora = ahora or datetime.utcnow()
    vencidas = session.execute(select(OfertaRescate).where(
        OfertaRescate.estado == "enviada", OfertaRescate.expira_at < ahora,
    )).scalars().all()
    for o in vencidas:
        o.estado = "expirada"
        bitacora.registrar(session, o.centro_id, "oferta_expirada", "oferta", o.id)
        ofrecer_siguiente(session, canal, session.get(Cita, o.cita_liberada_id))
    return len(vencidas)


def notificar_personal(session, canal, centro, cita_rescatada: Cita):
    """Aviso al centro para registrar la hora rescatada en su propio software."""
    bitacora.registrar(session, centro.id, "aviso_personal", "cita", cita_rescatada.id,
                       {"accion": "registrar_en_agenda_origen"})
