"""Cerebro conversacional (Prompt 4): reglas primero, LLM después."""
from sqlalchemy import select

from . import bitacora
from .models import Cita, Conversacion, Mensaje


def _cita_activa(session, paciente_id):
    return session.execute(select(Cita).where(
        Cita.paciente_id == paciente_id,
        Cita.estado.in_(["agendada", "confirmada", "en_riesgo"]),
    ).order_by(Cita.fecha_hora)).scalars().first()


def procesar_entrada(session, canal, centro, paciente, texto: str, llm=None) -> str:
    """Devuelve la acción tomada: confirmada | liberada | escalada | oferta_*"""
    from .rescate import liberar_cita, procesar_respuesta_oferta
    conv = session.query(Conversacion).filter_by(
        centro_id=centro.id, paciente_id=paciente.id).one_or_none()
    if not conv:
        conv = Conversacion(centro_id=centro.id, paciente_id=paciente.id)
        session.add(conv)
        session.flush()
    session.add(Mensaje(conversacion_id=conv.id, direccion="in", cuerpo=texto))

    # 0) ¿respuesta a una oferta de rescate pendiente?
    resultado_oferta = procesar_respuesta_oferta(session, canal, centro, paciente, texto)
    if resultado_oferta:
        return resultado_oferta

    t = texto.strip().lower()
    cita = _cita_activa(session, paciente.id)

    # 1) reglas: sin costo de LLM
    if t in {"1", "si", "sí", "si.", "sí."} and cita:
        accion, datos = "confirmar_cita", {}
    elif t in {"2", "no"} and cita:
        accion, datos = "marcar_no_asiste", {"motivo_general": "respuesta 2"}
    else:
        # 2) LLM con tool use (mock en tests, Anthropic en producción)
        if llm is None:
            from .llm import MockLLM
            llm = MockLLM()
        accion, datos = llm.decidir(centro.nombre, texto)

    if accion == "confirmar_cita" and cita:
        cita.estado = "confirmada"
        bitacora.registrar(session, centro.id, "cita_confirmada", "cita", cita.id)
        canal.enviar(session, paciente, "¡Gracias! Su hora quedó confirmada.")
        return "confirmada"
    if accion == "marcar_no_asiste" and cita:
        canal.enviar(session, paciente, "Entendido, liberamos su hora. Le contactaremos para reagendar.")
        liberar_cita(session, cita, motivo=datos.get("motivo_general", ""), canal=canal)
        return "liberada"
    conv.needs_human = True
    bitacora.registrar(session, centro.id, "escalada_humano", "conversacion", conv.id,
                       {"razon": datos.get("razon", "")})
    canal.enviar(session, paciente, "Le contactará una persona del centro a la brevedad.")
    return "escalada"
