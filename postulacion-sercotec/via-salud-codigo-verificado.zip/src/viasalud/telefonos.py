"""Normalización de teléfonos chilenos a E.164 (Prompt 2)."""
import re


def normalizar(raw: str | None) -> str | None:
    if not raw:
        return None
    d = re.sub(r"\D", "", str(raw))
    if d.startswith("56"):
        d = d[2:]
    d = d.lstrip("0")
    if len(d) == 9 and d.startswith("9"):      # móvil 9XXXXXXXX
        return "+56" + d
    if len(d) == 8:                             # móvil antiguo sin 9
        return "+569" + d
    return None
