"""Modo demo (Prompt 8): datos ficticios + guion del ciclo completo."""
from datetime import datetime, timedelta

from . import bitacora
from .asistente import procesar_entrada
from .canal import CanalFalso, plantilla_confirmacion
from .metricas import resumen
from .models import Centro, Cita, ListaRescate, PacienteContacto, Profesional


def poblar(session):
    centro = Centro(nombre="Centro Médico Demo", comuna="Concepción", tarifa_hora=30000)
    session.add(centro)
    session.flush()
    prof = Profesional(centro_id=centro.id, nombre="Dra. Rojas", especialidad="Oftalmología")
    session.add(prof)
    pacientes = {}
    for nombre, tel in [("Ana Soto", "+56911111111"), ("Bruno Díaz", "+56922222222"),
                        ("Carla Muñoz", "+56933333333")]:
        p = PacienteContacto(centro_id=centro.id, nombre=nombre, telefono=tel,
                             consentimiento_registrado=True)
        session.add(p)
        session.flush()
        pacientes[nombre.split()[0]] = p
    manana = (datetime.utcnow() + timedelta(days=1)).replace(hour=10, minute=0,
                                                             second=0, microsecond=0)
    citas = {}
    for i, key in enumerate(["Ana", "Bruno"]):
        c = Cita(centro_id=centro.id, profesional_id=prof.id,
                 paciente_id=pacientes[key].id, fecha_hora=manana + timedelta(minutes=30 * i))
        session.add(c)
        session.flush()
        citas[key] = c
    # Carla espera hora de oftalmología: es la lista de rescate
    session.add(ListaRescate(centro_id=centro.id, paciente_id=pacientes["Carla"].id,
                             especialidad="Oftalmología", prioridad=1, origen="sin_cupo"))
    bitacora.registrar(session, centro.id, "demo_poblada", "centro", centro.id)
    session.commit()
    return centro, prof, pacientes, citas


def correr_guion(session, log=print):
    """El ciclo completo: confirmar → cancelar → rescatar. Devuelve el resumen."""
    canal = CanalFalso()
    centro, prof, pacientes, citas = poblar(session)
    log("1) Confirmaciones enviadas:")
    for key, cita in citas.items():
        p = pacientes[key]
        canal.enviar(session, p, plantilla_confirmacion(
            p.nombre, centro.nombre, cita.fecha_hora.strftime("%d-%m-%Y"),
            cita.fecha_hora.strftime("%H:%M"), prof.nombre))
        log(f"   → {p.nombre}: {canal.enviados[-1][1][:60]}...")
    log("2) Ana responde '1' (confirma):")
    log("   → acción: " + procesar_entrada(session, canal, centro, pacientes["Ana"], "1"))
    log("3) Bruno responde 'no puedo, se me complicó' (cancela → se libera y se ofrece):")
    log("   → acción: " + procesar_entrada(session, canal, centro, pacientes["Bruno"],
                                           "no puedo, se me complicó"))
    log(f"   → oferta a Carla: {canal.enviados[-1][1][:80]}...")
    log("4) Carla responde 'SÍ' (toma el cupo):")
    log("   → acción: " + procesar_entrada(session, canal, centro, pacientes["Carla"], "SÍ"))
    session.commit()
    r = resumen(session, centro)
    log(f"5) Resumen del centro: {r}")
    ok = bitacora.verificar_cadena(session, centro.id)
    log(f"6) Cadena de bitácora íntegra: {ok}")
    return r, ok, canal
