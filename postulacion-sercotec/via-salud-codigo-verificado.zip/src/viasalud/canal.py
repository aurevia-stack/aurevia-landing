"""Capa de canal de mensajería (Prompt 3). En producción: partner oficial de
la API de WhatsApp Business (p. ej. Twilio). Aquí: interfaz + canal falso para
tests y sandbox de consola."""
from .models import Conversacion, Mensaje, PacienteContacto


def plantilla_confirmacion(nombre, centro, fecha, hora, profesional) -> str:
    return (f"Hola {nombre}, le recordamos su hora en {centro} el {fecha} a las "
            f"{hora} con {profesional}. Responda 1 para CONFIRMAR, 2 si NO PUEDE "
            f"ASISTIR, o escríbanos su duda.")


def plantilla_oferta(nombre, centro, fecha, hora, profesional, expira_min) -> str:
    return (f"Hola {nombre}, se liberó una hora en {centro} el {fecha} a las {hora} "
            f"con {profesional}. Responda SÍ en los próximos {expira_min} minutos "
            f"para tomarla.")


class CanalBase:
    def enviar(self, session, paciente: PacienteContacto, cuerpo: str) -> bool:
        raise NotImplementedError


class CanalFalso(CanalBase):
    """Registra los envíos en memoria y en la conversación. Sin red."""
    def __init__(self):
        self.enviados: list[tuple[str, str]] = []  # (telefono, cuerpo)

    def enviar(self, session, paciente, cuerpo) -> bool:
        if paciente.opt_out or not paciente.telefono:
            return False
        conv = session.query(Conversacion).filter_by(
            centro_id=paciente.centro_id, paciente_id=paciente.id).one_or_none()
        if not conv:
            conv = Conversacion(centro_id=paciente.centro_id, paciente_id=paciente.id)
            session.add(conv)
            session.flush()
        session.add(Mensaje(conversacion_id=conv.id, direccion="out", cuerpo=cuerpo))
        self.enviados.append((paciente.telefono, cuerpo))
        return True
