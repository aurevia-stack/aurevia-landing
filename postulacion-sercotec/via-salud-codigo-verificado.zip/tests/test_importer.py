from viasalud.importer import importar_csv
from viasalud.models import Centro, Cita
from viasalud.telefonos import normalizar

CSV_DENTAL = """Fecha,Hora,Paciente,Celular,Dentista,Servicio,Minutos
02-09-2026,09:00,Ana Soto,9 1111 1111,Dr. Pérez,Dental,45
02-09-2026,10:00,Bruno Díaz,+56 9 2222 2222,Dr. Pérez,Dental,45
02-09-2026,11:00,Sin Fono,,Dr. Pérez,Dental,45
"""

CSV_MEDICO = """fecha;hora;nombre;fono;medico;especialidad
"""  # se usa solo para probar el error de separador


def test_normalizacion_telefonos():
    assert normalizar("9 1111 1111") == "+56911111111"
    assert normalizar("+56 9 2222 2222") == "+56922222222"
    assert normalizar("569 3333 3333") == "+56933333333"
    assert normalizar("") is None
    assert normalizar("123") is None


def test_import_idempotente_y_liberacion(session):
    centro = Centro(nombre="C1", comuna="Concepción")
    session.add(centro); session.commit()
    s1 = importar_csv(session, centro, CSV_DENTAL)
    assert s1["nuevas"] == 3 and s1["incontactables"] == 1
    s2 = importar_csv(session, centro, CSV_DENTAL)  # re-importar: sin duplicados
    assert s2["nuevas"] == 0 and s2["liberadas"] == 0
    assert session.query(Cita).count() == 3
    # Bruno desaparece del archivo => su cita queda liberada
    sin_bruno = "\n".join(l for l in CSV_DENTAL.splitlines() if "Bruno" not in l) + "\n"
    s3 = importar_csv(session, centro, sin_bruno)
    assert s3["liberadas"] == 1
    estados = {c.paciente.nombre: c.estado for c in session.query(Cita)}
    assert estados["Bruno Díaz"] == "liberada"
