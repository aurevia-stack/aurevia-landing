from viasalud.demo import correr_guion


def test_ciclo_completo_demo(session):
    resumen, cadena_ok, canal = correr_guion(session, log=lambda *_: None)
    assert cadena_ok is True
    assert resumen["confirmadas"] == 1        # Ana
    assert resumen["rescatadas"] == 1         # el cupo de Bruno tomado por Carla
    assert resumen["liberadas_sin_rescatar"] == 1  # la cita original de Bruno queda liberada
    assert resumen["horas_rescatadas"] == 0.5
    assert resumen["pesos_recuperados"] == 15000   # 30 min a $30.000/hora
    assert resumen["tasa_aceptacion_ofertas"] == 1.0
    assert len(canal.enviados) >= 5
