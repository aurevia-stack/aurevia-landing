from datetime import datetime, timedelta

from viasalud.asistente import procesar_entrada
from viasalud.canal import CanalFalso
from viasalud.demo import poblar
from viasalud.models import Cita, OfertaRescate
from viasalud.rescate import expirar_ofertas


def test_regla_1_confirma_sin_llm(session):
    canal = CanalFalso()
    centro, prof, pac, citas = poblar(session)
    assert procesar_entrada(session, canal, centro, pac["Ana"], "1") == "confirmada"
    assert session.get(Cita, citas["Ana"].id).estado == "confirmada"


def test_cancelacion_dispara_oferta_secuencial(session):
    canal = CanalFalso()
    centro, prof, pac, citas = poblar(session)
    r = procesar_entrada(session, canal, centro, pac["Bruno"], "no puedo asistir")
    assert r == "liberada"
    assert session.get(Cita, citas["Bruno"].id).estado == "liberada"
    # Carla (lista de rescate, prioridad 1) recibió la oferta
    assert any("se liberó una hora" in cuerpo for _, cuerpo in canal.enviados)
    oferta = session.query(OfertaRescate).one()
    assert oferta.paciente.nombre == "Carla Muñoz" and oferta.estado == "enviada"


def test_aceptar_oferta_rescata_el_cupo(session):
    canal = CanalFalso()
    centro, prof, pac, citas = poblar(session)
    procesar_entrada(session, canal, centro, pac["Bruno"], "2")
    r = procesar_entrada(session, canal, centro, pac["Carla"], "SÍ")
    assert r == "oferta_aceptada"
    rescatada = session.query(Cita).filter_by(estado="rescatada").one()
    assert rescatada.paciente.nombre == "Carla Muñoz"
    assert rescatada.fecha_hora == citas["Bruno"].fecha_hora


def test_oferta_expira_y_no_hay_mas_candidatos(session):
    canal = CanalFalso()
    centro, prof, pac, citas = poblar(session)
    procesar_entrada(session, canal, centro, pac["Bruno"], "2")
    n = expirar_ofertas(session, canal, ahora=datetime.utcnow() + timedelta(hours=1))
    assert n == 1
    assert session.query(OfertaRescate).one().estado == "expirada"


def test_consulta_clinica_escala_a_humano(session):
    canal = CanalFalso()
    centro, prof, pac, citas = poblar(session)
    r = procesar_entrada(session, canal, centro, pac["Ana"],
                         "me duele mucho el ojo, ¿qué remedio me tomo?")
    assert r == "escalada"
    assert any("persona del centro" in cuerpo for _, cuerpo in canal.enviados)
