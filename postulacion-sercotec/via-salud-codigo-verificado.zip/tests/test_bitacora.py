import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from viasalud import bitacora
from viasalud.models import Centro


def test_cadena_de_hashes_valida(session):
    c = Centro(nombre="C1", comuna="Concepción")
    session.add(c); session.flush()
    for i in range(5):
        bitacora.registrar(session, c.id, f"evento_{i}", "test", i)
    session.commit()
    assert bitacora.verificar_cadena(session, c.id) is True


def test_alteracion_rompe_la_cadena_y_es_detectada(session):
    c = Centro(nombre="C1", comuna="Concepción")
    session.add(c); session.flush()
    bitacora.registrar(session, c.id, "a", "test", 1)
    bitacora.registrar(session, c.id, "b", "test", 2)
    session.commit()
    # el trigger de Postgres debe IMPEDIR el UPDATE
    with pytest.raises(DBAPIError):
        session.execute(text("UPDATE evento_bitacora SET tipo='hackeado' WHERE tipo='a'"))
        session.commit()
    session.rollback()
    # y el DELETE también
    with pytest.raises(DBAPIError):
        session.execute(text("DELETE FROM evento_bitacora"))
        session.commit()
    session.rollback()
    assert bitacora.verificar_cadena(session, c.id) is True
