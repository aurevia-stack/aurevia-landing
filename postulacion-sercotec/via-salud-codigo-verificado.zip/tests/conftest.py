import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

from viasalud.models import Base, crear_esquema

URL = os.environ.get("DATABASE_URL_TEST",
                     "postgresql+psycopg2://viasalud:viasalud@localhost:5432/viasalud")


@pytest.fixture()
def session():
    engine = create_engine(URL, future=True)
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
    crear_esquema(engine)
    s = sessionmaker(bind=engine, future=True, expire_on_commit=False)()
    yield s
    s.close()
    engine.dispose()
